// Remove accents and lowercase
function normalize(text) {
  return text.normalize('NFD').replace(/[̀-\u036f]/g, '').toLowerCase();
}

// Load JSON data
let bairrosData = {};
fetch('bairros.json')
  .then(response => response.json())
  .then(data => { bairrosData = data; renderAllCards(); })
  .catch(err => console.error('Erro ao carregar JSON:', err));

// Render all cards initially
function renderAllCards() {
  const cards = document.getElementById('cards');
  cards.innerHTML = '';
  Object.keys(bairrosData).sort().forEach(key => {
    createCard(key, bairrosData[key]);
  });
}

// Create a card element
function createCard(key, dia) {
  const cards = document.getElementById('cards');
  const card = document.createElement('div');
  card.className = 'card';
  const label = key.charAt(0).toUpperCase() + key.slice(1);
  card.textContent = `${label}: 🗓️ ${dia}`;
  cards.appendChild(card);
}

// Filter function
function filtrar() {
  const q = normalize(document.getElementById('search').value);
  const result = document.getElementById('result');
  const cards = document.getElementById('cards');
  cards.innerHTML = '';
  if (!q) {
    result.textContent = 'Digite um bairro acima. 🔍';
    renderAllCards();
    return;
  }
  const matches = Object.keys(bairrosData).filter(key => normalize(key).includes(q));
  if (matches.length) {
    matches.forEach(key => createCard(key, bairrosData[key]));
    result.textContent = matches.length > 1 ? `${matches.length} resultados encontrados.` : `${matches[0].charAt(0).toUpperCase()+matches[0].slice(1)}: 🗓️ ${bairrosData[matches[0]]}`;
  } else {
    result.textContent = 'Bairro não encontrado. ❌';
  }
}

// Mode toggles
document.getElementById('toggle-modo').addEventListener('click', () => {
  document.body.classList.toggle('light');
  localStorage.setItem('modo', document.body.classList.contains('light') ? 'claro' : '');
});
document.getElementById('toggle-contrast').addEventListener('click', () => {
  document.body.classList.toggle('high-contrast');
  localStorage.setItem('contrast', document.body.classList.contains('high-contrast') ? 'high' : '');
});

// Initial load
window.addEventListener('DOMContentLoaded', () => {
  const modo = localStorage.getItem('modo');
  if (modo === 'claro') document.body.classList.add('light');
  const contrast = localStorage.getItem('contrast');
  if (contrast === 'high') document.body.classList.add('high-contrast');
  document.getElementById('search').addEventListener('input', filtrar);
});
